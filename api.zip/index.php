<?php
include_once("config.php");
include_once("router/AlunoRouter.php");

header("Content-type: application/json; charset=UTF-8");
